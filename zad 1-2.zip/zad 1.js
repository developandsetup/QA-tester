describe('Stage Volcano - Registration and Login tests', () => {
  const randomSuffix = Math.floor(Math.random() * 10000);
  const validEmail = `testuser${randomSuffix}@example.com`;
  const validPassword = 'TestPassword123!';

  const invalidEmail = 'invalid-email'; // Neispravan format emaila
  const shortPassword = '123'; // Preslaba lozinka

  it('should register a new user successfully', () => {
    cy.visit('https://www.stage-volcano.com/');

    cy.contains('Sign Up').click();

    cy.get('input[name="email"]').type(validEmail);
    cy.get('input[name="password"]').type(validPassword);
    cy.get('input[name="confirmPassword"]').type(validPassword);
    cy.get('button[type="submit"]').click();

    // Provjera da je registracija uspješna
    cy.url().should('include', '/dashboard'); // Prilagodi URL ako dashboard ima drugo ime
  });

  it('should log out the user', () => {
    cy.get('button[aria-label="Logout"]').click(); // Prilagodi selektor ako treba

    cy.url().should('include', '/login');
  });

  it('should log in with the registered user', () => {
    cy.contains('Login').click();

    cy.get('input[name="email"]').type(validEmail);
    cy.get('input[name="password"]').type(validPassword);
    cy.get('button[type="submit"]').click();

    cy.url().should('include', '/dashboard');
  });

  it('should show error on registration with invalid email', () => {
    cy.visit('https://www.stage-volcano.com/');

    cy.contains('Sign Up').click();

    cy.get('input[name="email"]').type(invalidEmail);
    cy.get('input[name="password"]').type(validPassword);
    cy.get('input[name="confirmPassword"]').type(validPassword);
    cy.get('button[type="submit"]').click();

    // Očekivana greška
    cy.contains('Please enter a valid email').should('be.visible');
  });

  it('should show error on registration with weak password', () => {
    cy.visit('https://www.stage-volcano.com/');

    cy.contains('Sign Up').click();

    cy.get('input[name="email"]').type(`weak${randomSuffix}@example.com`);
    cy.get('input[name="password"]').type(shortPassword);
    cy.get('input[name="confirmPassword"]').type(shortPassword);
    cy.get('button[type="submit"]').click();

    // Očekivana greška za lozinku
    cy.contains('Password must be at least 8 characters').should('be.visible');
  });

  it('should fail login with random credentials', () => {
    cy.visit('https://www.stage-volcano.com/');

    cy.contains('Login').click();

    cy.get('input[name="email"]').type(`randomuser${randomSuffix}@example.com`);
    cy.get('input[name="password"]').type('WrongPassword123!');
    cy.get('button[type="submit"]').click();

    // Provjera prikaza greške
    cy.contains('Invalid email or password').should('be.visible');
  });
});
